#include "../header/mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[]) {
    // creates an instance of the application class
    QApplication a(argc, argv);

    // window is created
    MainWindow w;

    // makes GUI elements appear on the screen
    w.show();

    // handles user events such as add and edit
    return a.exec();
}

