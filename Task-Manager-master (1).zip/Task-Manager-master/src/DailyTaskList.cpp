#include "../header/DailyTaskList.h"

// adds a task to the taskList
void DailyTaskList::addTask(const Task& task) {
    taskList.append(task);
}

// removes a task from the tasklist
void DailyTaskList::removeTask(const int index) {
    if(index >= 0 && index < taskList.size()) {
        taskList.removeAt(index);
    }
}

// as long as the index is within taskList range, a task is placed within the taskList
void DailyTaskList::updateTask(int index, const Task &updatedTask) {
    // Check if the provided index is valid
    if (index >= 0 && index < taskList.size()) {
        taskList[index] = updatedTask;
    }
}

// tasks are sorted by date, using swap function
void DailyTaskList::sortTasksByDate() {
    int size = taskList.size();
    bool isSorted;

    do {
        isSorted = true;
        for (int i = 0; i < size - 1; ++i) {
            if (taskList[i].getDueDate() > taskList[i + 1].getDueDate()) {
                std::swap(taskList[i], taskList[i + 1]);
                isSorted = false;
            }
        }
    }
    while (!isSorted);
}


// returns task at given index
Task DailyTaskList::getTask(int index) const {
    return taskList.at(index);
}

// displays the taskList size
int DailyTaskList::getTasksSize() const {
    return taskList.size();
}

