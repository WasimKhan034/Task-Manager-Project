#ifndef DAILYTASKLIST_H
#define DAILYTASKLIST_H

#pragma once

#include <QList>
#include "Task.h"

class DailyTaskList {
private:
    QList<Task> taskList;

public:
    void addTask(const Task& task);
    void removeTask(int index);
    void updateTask(int index, const Task &updatedTask);
    void sortTasksByDate();
    Task getTask(int) const;
    int getTasksSize() const;
};

#endif // DAILYTASKLIST_H
